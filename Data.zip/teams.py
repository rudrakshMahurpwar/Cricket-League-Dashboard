import csv

def process_input_data(input_data):
    """Process pasted input data into a list of rows."""
    # Split the input by newline to get each line
    rows = input_data.strip().split("\n")
    
    # Create a list of lists where each list represents a row of data
    processed_data = [row.split(",") for row in rows]
    
    return processed_data

def create_csv(data, filename="teams.csv"):
    """Create CSV file from the processed data."""
    # Define the header for the CSV file
    header = [
        "team_id", "team_name", "short_name", "home_ground", "captain", 
        "coach", "years_active", "team_colour", "most_successful_player"
    ]
    
    # Open the CSV file in write mode
    with open(filename, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        
        # Write the header to the file
        writer.writerow(header)
        
        # Write the data rows to the file
        for row in data:
            writer.writerow(row)

def main():
    # Paste your complete team data here
    input_data = """team_id,team_name,short_name,home_ground,captain,coach,years_active,team_colour,most_successful_player
1,Chennai Super Kings,CSK,M. A. Chidambaram Stadium,MS Dhoni,Stephen Fleming,2008-2024,Yellow,Suresh Raina
2,Mumbai Indians,MI,Wankhede Stadium,Rohit Sharma,Mahela Jayawardene,2008-2024,Blue,Rohit Sharma
3,Royal Challengers Bangalore,RCB,M. Chinnaswamy Stadium,Virat Kohli,Simon Katich,2008-2024,Red,AB de Villiers
4,Kolkata Knight Riders,KKR,Eden Gardens,Eoin Morgan,Brendon McCullum,2008-2024,Purple and Gold,Gautam Gambhir
5,Delhi Capitals,DC,Arun Jaitley Stadium,Rishabh Pant,Ricky Ponting,2008-2024,Blue and Red,Shikhar Dhawan
6,Punjab Kings,PBKS,Punjab Cricket Association IS Bindra Stadium,KL Rahul,Anil Kumble,2008-2024,Red and Silver,Shaun Marsh
7,Rajasthan Royals,RR,Sawai Mansingh Stadium,Sanju Samson,Andrew McDonald,2008-2024,Blue,Shane Watson
8,Sunrisers Hyderabad,SRH,Rajiv Gandhi International Cricket Stadium,David Warner,Trevor Bayliss,2013-2024,Orange and Black,David Warner
9,Gujarat Titans,GT,Narendra Modi Stadium,Hardik Pandya,Ashish Nehra,2022-2024,Blue and Gold,Hardik Pandya
10,Lucknow Super Giants,LSG,Bharat Ratna Shri Atal Bihari Vajpayee Ekana Cricket Stadium,KL Rahul,Andy Flower,2022-2024,Blue,KL Rahul
11,Deccan Chargers,DC,Hyderabad,Adam Gilchrist,Darren Lehmann,2008-2012,Blue,Adam Gilchrist
12,Pune Warriors India,PWI,Maharashtra Cricket Association Stadium,Yuvraj Singh,Allan Donald,2011-2013,Blue,Yuvraj Singh
13,Kochi Tuskers Kerala,KTK,Jawaharlal Nehru Stadium,Mahela Jayawardene,Geoff Lawson,2011,Orange and Purple,Brendon McCullum
14,Rising Pune Supergiant,RPS,Maharashtra Cricket Association Stadium,Steve Smith,Stephen Fleming,2016-2017,Blue and Pink,Steve Smith
15,Gujarat Lions,GL,Saurashtra Cricket Association Stadium,Suresh Raina,Brad Hodge,2016-2017,Orange and Blue,Suresh Raina
"""

    # Process the input data
    processed_data = process_input_data(input_data)
    
    # Create the CSV file
    create_csv(processed_data)
    print(f"\nCSV file 'teams.csv' created successfully!")

# Run the script
if __name__ == "__main__":
    main()
